﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Printing;
using ES_Project.otherConnections;

namespace ES_Project
{
    public partial class Form3 : Form
    {
        List<string> contactNumbers = new List<string>();
        List<string> emailAddresses = new List<string>();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            txt_Name.Clear();
            txt_Add.Clear();
            txt_Con.Clear();
            contactNumbers.RemoveRange(0, contactNumbers.Count - 1);
            emailAddresses.RemoveRange(0, emailAddresses.Count - 1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(emailAddresses.Count == 0)
            {
                emailAddresses.Add(textBox7.Text);
            }
            if(contactNumbers.Count == 0)
            {
                contactNumbers.Add(txt_Con.Text);
            }
            new db_connection.customers().newCustomer(txt_Name.Text, textBox1.Text, textBox2.Text, txt_Add.Text, textBox4.Text, Properties.Settings.Default.username, textBox5.Text, textBox6.Text, emailAddresses[0]);
            for(int i = 0; i < contactNumbers.Count; i++)
            {
                new db_connection.CustomerContact().newPhoneNumber(contactNumbers[i], (emailAddresses.Count > i) ? "" : emailAddresses[i]);
            }
            DialogResult result = MessageBox.Show("Customer Registration completed. Whould you like to register the pawning item of the customer.", "EK Pawning center - customer registration", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(result.ToString() == "Yes")
            {
                frm_registerPawnItem item = new frm_registerPawnItem(textBox3.Text);
                item.Show();
                this.Hide();
            }
        }

            private void textBox1_TextChanged(object sender, EventArgs e)
            {

            }

        private void button4_Click(object sender, EventArgs e)
        {
            contactNumbers.Add(txt_Con.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int count = 0;
            while(contactNumbers[count] == txt_Con.Text)
            {
                count++;
            }
            txt_Con.Text = contactNumbers[count++];
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int count = 0; 
            while(emailAddresses[count] == textBox7.Text)
            {
                count++;
            }
            textBox7.Text = emailAddresses[count++];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            emailAddresses.Add(textBox7.Text);
        }
    }
}


