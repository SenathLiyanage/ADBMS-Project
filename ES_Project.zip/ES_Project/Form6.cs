﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ES_Project.otherConnections;

namespace ES_Project
{
    public partial class Form6 : Form
    {

        private string itemId;
        public Form6(string itemId)
        {
            InitializeComponent();
            this.itemId = itemId;
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form6 = new Form6("");
            form6.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            string customerNic = new db_connection.PawnedItems().getAnEntry("200008101616", 1);
            textBox_1.Text = customerNic;
            MessageBox.Show(new db_connection.customers().getAnEntry(customerNic, 1) + " " + new db_connection.customers().getAnEntry(customerNic, 2));
            textBox_2.Text = new db_connection.customers().getAnEntry(customerNic, 1) + " " + new db_connection.customers().getAnEntry(customerNic, 2);
            textBox_3.Text = new db_connection.customers().getAnEntry(customerNic, 4) + ", " + new db_connection.customers().getAnEntry(customerNic, 5) + ", " + new db_connection.customers().getAnEntry(customerNic, 6) + ", " + new db_connection.customers().getAnEntry(customerNic, 7);
            textBox_4.Text = new db_connection.CustomerContact().getAnEntry(customerNic, 1, true);
            textBox_5.Text = new db_connection.PawnedItems().getAnEntry(this.itemId, 2) + "(" + this.itemId + ") - " + new db_connection.PawnedItems().getAnEntry(this.itemId, 3);
            textBox_6.Text = new db_connection.PawnedItems().getAnEntry(this.itemId, 4);
            textBox_8.Text = new db_connection.PawnedItems().getAnEntry(this.itemId, 8);
            textBox_11.Text = textBox_8.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += new PrintPageEventHandler(printDocument_PrintPage);
            printDocument.Print();
        }

        private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bitmap = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bitmap, new Rectangle(0, 0, this.Width, this.Height));
            e.Graphics.DrawImage(bitmap, 0, 0);
        }
    }
}
