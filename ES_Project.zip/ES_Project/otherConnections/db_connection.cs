﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ES_Project.otherConnections
{
    class db_connection
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;

        public void createConnection()
        {
            connection = new SqlConnection("Data Source=(localdb)\\local;Initial Catalog=dk_pawn_center;Integrated Security=True");
            command = new SqlCommand();
            command.Connection = connection;
        }

        public string callReturnText(string cipherText)
        {
            return new encryption().Decrypt(cipherText);
        }

        public string callInsertionText(string plainText)
        {
            return new encryption().Encrypt(plainText);
        }

        //database customers
        public class customers
        {
            private string tableName = "customers";
            db_connection db = new db_connection();

            private string firstName = "firstName";
            private string lastName = "lastName";
            private string otherNames = "otherNames";
            private string id = "id";
            private string line1 = "line1";
            private string line2 = "line2";
            private string line3 = "line3";
            private string city = "city";
            private string secondaryContactMethod = "secondaryContactMethod";
            private string registeredBy = "registeredBy";

            public void newCustomer(string firstName, string lastName, string id, string line1, string line2, string registeredBy, string line3 = "", string city = "", string secondaryContactMethod = "")
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(firstName) + "', '" + db.callInsertionText(lastName) + "', '" + db.callInsertionText(otherNames) + "', '" + db.callInsertionText(line1) + "', '" + db.callInsertionText(line2) + "', '" + db.callInsertionText(line3) + "', '" + db.callInsertionText(city) + "', '" + db.callInsertionText(secondaryContactMethod) + "', '" + db.callInsertionText(registeredBy) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }

            public string getAnEntry(string nic, int requiringIndex)
            {
                string entry = "";

                db.createConnection();
                db.command.CommandText = "select * from " + this.tableName + " where " + this.id + " = '" + db.callInsertionText(nic) + "'";
                db.connection.Open();
                db.reader = db.command.ExecuteReader();
                while (db.reader.Read())
                {
                    switch (requiringIndex)
                    {
                        case 0:
                            entry = db.callReturnText(db.reader[this.id].ToString());
                            break;

                        case 1:
                            entry = db.callReturnText(db.reader[this.firstName].ToString());
                            break;

                        case 2:
                            entry = db.callReturnText(db.reader[this.lastName].ToString());
                            break;

                        case 3:
                            entry = db.callReturnText(db.reader[this.otherNames].ToString());
                            break;

                        case 4:
                            entry = db.callReturnText(db.reader[this.line1].ToString());
                            break;

                        case 5:
                            entry = db.callReturnText(db.reader[this.line2].ToString());
                            break;

                        case 6:
                            entry = db.callReturnText(db.reader[this.line3].ToString());
                            break;

                        case 7:
                            entry = db.callReturnText(db.reader[this.city].ToString());
                            break;
                    }
                }
                db.connection.Close();

                return entry;
            }
        }

        //database customer_contact
        public class CustomerContact
        {
            private string tableName = "customer_contact";
            db_connection db = new db_connection();

            private string id = "id";
            private string phoneNumber = "phoneNumber";
            private string email = "email";

            public void newPhoneNumber(string phoneNumber, string id, string email = "")
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(phoneNumber) + "', '" + db.callInsertionText(email) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }

            public string getAnEntry(string nic, int requiringIndex, bool isCustomerNic = false)
            {
                string entry = "";

                db.createConnection();
                db.command.CommandText = !isCustomerNic ? "select * from " + this.tableName + " where " + this.phoneNumber + " = '" + db.callInsertionText(nic) + "'" : "select * from " + this.tableName + " where " + this.id + " = '" + db.callInsertionText(nic)+ "'";
                db.connection.Open();
                db.reader = db.command.ExecuteReader();
                while (db.reader.Read())
                {
                    switch (requiringIndex)
                    {
                        case 0:
                            entry = db.callReturnText(db.reader[this.id].ToString());
                            break;

                        case 1:
                            entry = db.callReturnText(db.reader[this.phoneNumber].ToString());
                            break;

                        case 2:
                            entry = db.callReturnText(db.reader[this.email].ToString());
                            break;
                    }
                }
                db.connection.Close();

                return entry;
            }
        }

        //database pawned_item
        public class PawnedItems
        {
            private string tableName = "pawned_item";
            db_connection db = new db_connection();

            private string id = "id";
            private string ownerId = "ownerId";
            private string itemName = "itemName";
            private string description = "itemDescription";
            private string estimatedCarrotValue = "estimatedCarrotValue";
            private string descriptionApprovedAmount = "descriptionApprovedAmount";
            private string yearlyInterest = "yearlyInterest";
            private string paymentMethod = "paymentMethod";
            private string takenAmount = "takenAmount";
            private string calculateinterestFor = "calculateInterestFor";
            private string approvedStaff = "approvedStaff";
            private string ownerVerification = "ownerVerification";
            private string estimatedValue = "estimatedValue";
            private string approvedAmount = "approvedAmount";
            private string storedLockerId = "storedLockerId";

            public void newPawnedItem(string id, string ownerId, string itemName, string description, string estiamtedCarrotValue, string descriptionApprovedAmount, string yearlyInterest, string paymentMethod, string takenAmount, string calculateInterestFor, string approvedStaff, string ownerVerification, string estimatedValue, string approvedAmount, string storedLockerId)
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(ownerId) + "', '" + db.callInsertionText(itemName) + "', '" + db.callInsertionText(description) + "', '" + db.callInsertionText(estimatedCarrotValue) + "', '" + db.callInsertionText(descriptionApprovedAmount) + "', '" + db.callInsertionText(yearlyInterest) + "', '" + db.callInsertionText(paymentMethod) + "', '" + db.callInsertionText(takenAmount) + "', '" + db.callInsertionText(calculateInterestFor) + "', '" + db.callInsertionText(approvedStaff) + "', '" + db.callInsertionText(ownerVerification) + "', '" + db.callInsertionText(estimatedValue) + "', '" + db.callInsertionText(approvedAmount) + "', '" + db.callInsertionText(storedLockerId) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }

            public string getAnEntry(string id, int requiringIndex)
            {
                string entry = "";

                db.createConnection();
                db.command.CommandText = "select * from " + this.tableName + " where " + this.id + " = '" + db.callInsertionText(id) + "'";
                db.connection.Open();
                db.reader = db.command.ExecuteReader();
                while (db.reader.Read())
                {
                    switch (requiringIndex)
                    {
                        case 0:
                            entry = db.callReturnText(db.reader[this.id].ToString());
                            break;

                        case 1:
                            entry = db.reader[this.ownerId].ToString();
                            entry = db.callReturnText(entry);
                            break;

                        case 2:
                            entry = db.callReturnText(db.reader[this.itemName].ToString());
                            break;

                        case 3:
                            entry = db.callReturnText(db.reader[this.description].ToString());
                            break;

                        case 4:
                            entry = db.callReturnText(db.reader[this.estimatedCarrotValue].ToString());
                            break;

                        case 8:
                            entry = db.callReturnText(db.reader[this.takenAmount].ToString());
                            break;
                    }
                }
                db.connection.Close();

                return entry;
            }
        }

        //databas staffmembers
        public class StaffMembers
        {
            private string tableName = "staff_members";
            db_connection db = new db_connection();

            private string id = "id";
            private string firstName = "firstName";
            private string lastName = "lastName";
            private string otherNames = "otherNames";
            private string line1 = "line1";
            private string line2 = "line2";
            private string line3 = "line3";
            private string city = "city";
            private string availableLeaves = "availableLeaves";
            private string username = "username";
            private string password = "userPassword";
            private string currentEmployementStatus = "currentEmployementStatus";
            private string jobDescriptionLink = "jobDescriptionLink";
            private string cvLink = "cvLink";
            private string positionId = "positionId";
            private string registeredDay = "registeredDay";
            private string registeredMonth = "registeredMonth";
            private string registeredYear = "registeredYear";
            private string applicableLeaves = "applicableLeaves";

            public void newStaffRegistration(string id, string firstName, string lastName, string otherNames, string line1, string line2, string line3, string city, string availableLeaves, string username, string password, string currentEmployementStatus, string jobDescriptionLink, string cvLink, string positionId, string applicableLeaves, string registeredDay = "", string registeredMonth = "", string registeredyear = "")
            {
                registeredDay = registeredDay == "" ? DateTime.Now.ToString("dd") : registeredDay;
                registeredMonth = registeredMonth == "" ? DateTime.Now.ToString("MM") : registeredMonth;
                registeredYear = registeredyear == "" ? DateTime.Now.ToString("yyyy") : registeredyear;

                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values('" + db.callInsertionText(id) + "', '" + db.callInsertionText(firstName) + "', '" + db.callInsertionText(lastName) + "', '" + db.callInsertionText(otherNames) + "', '" + db.callInsertionText(line1) + "', '" + db.callInsertionText(line2) + "', '" + db.callInsertionText(line3) + "', '" + db.callInsertionText(city) + "', '" + db.callInsertionText(availableLeaves) + "', '" + db.callInsertionText(username) + "', '" + db.callInsertionText(password) + "', '" + db.callInsertionText(currentEmployementStatus) + "', '" + db.callInsertionText(jobDescriptionLink) + "', '" + db.callInsertionText(cvLink) + "', '" + db.callInsertionText(positionId) + "', '" + db.callInsertionText(registeredDay) + "', '" + db.callInsertionText(registeredMonth) + "', '" + db.callInsertionText(registeredYear) + "', '" + db.callInsertionText(applicableLeaves) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }

            public int checkCredentials(string username, string userpassword)
            {
                int count = 0;

                db.createConnection();
                db.command.CommandText = "select " + this.username + ", " + this.password + " from " + this.tableName + " where " + this.username + " = '" + db.callInsertionText(username) + "' and " + this.password + " = '" + db.callInsertionText(userpassword) + "'";
                db.connection.Open();
                db.reader = db.command.ExecuteReader();
                while (db.reader.Read())
                {
                    count++;
                }
                db.connection.Close();
                return count;
            }
        }

        //database staff_position
        public class StaffPosition
        {
            private string tableName = "staff_position";
            db_connection db = new db_connection();

            private string id = "id";
            private string position = "position";
            private string basicSalary = "basicSalary";

            public void newPositionRegistration(string id, string position, string basicSalary)
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values('" + db.callInsertionText(id) + "', '" + db.callInsertionText(position) + "', '" + db.callInsertionText(basicSalary) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database staff_contact_number
        public class StaffContactNumber
        {
            private string tableName = "staff_contact_number";
            db_connection db = new db_connection();

            private string id = "id";
            private string phoneNumber = "phoneNumber";
            private string email = "email";
            private string bankAccountNumber = "bankAccoutNumber";

            public void newContactNumber(string id, string phoneNumber, string email = "", string bankAccountNumber = "")
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(phoneNumber) + "', '" + db.callInsertionText(email) + "', '" + db.callInsertionText(bankAccountNumber) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database agrementLinks
        public class Agrementlinks
        {
            private string tableName = "agrement_links";
            db_connection db = new db_connection();

            private string id = "id";
            private string agrementLink = "agrementLink";

            public void newAgrementLink(string id, string agrementLink)
            {
                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values('" + db.callInsertionText(id) + "', '" + db.callInsertionText(agrementLink) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database paymentLog
        public class PaymentLog
        {
            private string tableName = "payment_log";
            db_connection db = new db_connection();

            private string id = "id";
            private string table = "usingTable";
            private string description = "logDescription";
            private string day = "registeredDay";
            private string month = "registeredMonth";
            private string year = "registeredYear";
            private string hour = "registeredHour";
            private string minute = "registeredMinute";
            private string transferedAmount = "transferedAmount";
            private string accountNumber = "accountNumber";
            private string bank = "bank";
            private string actionPerformedBy = "actionperformedBy";
            private string capital = "capital";
            private string paymentMethod = "paymentMethod";
            private string transactionConfirmation = "transactionConfirmation";

            public void newPaymentLog(string id, string table, string description, string transferedAmount, string accountNumber, string bank, string actionPerformedBy, string capital, string paymentMethod, string transactionConfirmation, string day = "", string month = "", string year = "", string hour = "", string minute = "")
            {
                day = day == "" ? DateTime.Now.ToString("dd") : day;
                month = month == "" ? DateTime.Now.ToString("MM") : month;
                year = year == "" ? DateTime.Now.ToString("yyyy") : year;
                hour = hour == "" ? DateTime.Now.ToString("hh") : hour;
                minute = minute == "" ? DateTime.Now.ToString("mm") : minute;

                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(table) + "', '" + db.callInsertionText(description) + "', '" + db.callInsertionText(day) + "', '" + db.callInsertionText(month) + "', '" + db.callInsertionText(year) + "', '" + db.callInsertionText(hour) + "', '" + db.callInsertionText(minute) + "', '" + db.callInsertionText(transferedAmount) + "', '" + db.callInsertionText(accountNumber) + "', '" + db.callInsertionText(bank) + "', '" + db.callInsertionText(actionPerformedBy) + "', '" + db.callInsertionText(capital) + "', '" + db.callInsertionText(paymentMethod) + "', '" + db.callInsertionText(transactionConfirmation) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database log
        public class Log
        {
            private string tableName = "general_log";
            db_connection db = new db_connection();

            private string id = "id";
            private string table = "usingTable";
            private string description = "logDescription";
            private string day = "registeredDay";
            private string month = "registeredMonth";
            private string year = "registeredYear";
            private string hour = "registeredHour";
            private string minute = "registeredMinute";
            private string actionPerformedBy = "actionPerformedBy";

            public void newLog(string id, string table, string description, string actionPerformedBy, string day = "", string month = "", string year = "", string hour = "", string minute = "")
            {
                day = day == "" ? DateTime.Now.ToString("dd") : day;
                month = month == "" ? DateTime.Now.ToString("MM") : month;
                year = year == "" ? DateTime.Now.ToString("yyyy") : year;
                hour = hour == "" ? DateTime.Now.ToString("hh") : hour;
                minute = minute == "" ? DateTime.Now.ToString("mm") : minute;

                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(table) + "', '" + db.callInsertionText(description) + "', '" + db.callInsertionText(day) + "', '" + db.callInsertionText(month) + "', '" + db.callInsertionText(year) + "', '" + db.callInsertionText(hour) + "', '" + db.callInsertionText(minute) + "', '" + db.callInsertionText(actionPerformedBy) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database bills
        public class Bills
        {
            private string tableName = "bills";
            db_connection db = new db_connection();

            private string id = "id";
            private string customerId = "customerId";
            private string detailsFiledBy = "detailsFilledBy";
            private string isCustomerAware = "isCustomerAware";
            private string type = "billType";
            private string isIncome = "isIncome";
            private string interest = "interest";
            private string total = "total";
            private string day = "registeredDay";
            private string month = "registeredMonth";
            private string year = "registeredYear";
            private string hour = "registeredHour";
            private string minute = "registeredMinute";

            public void newBill(string id, string customerId, string detailsFilledBy, string isCustomerAware, string type, string isIncome, string interest, string total, string day = "", string month = "", string year = "", string hour = "", string minute = "")
            {
                day = day == "" ? DateTime.Now.ToString("dd") : day;
                month = month == "" ? DateTime.Now.ToString("MM") : month;
                year = year == "" ? DateTime.Now.ToString("yyyy") : year;
                hour = hour == "" ? DateTime.Now.ToString("hh") : hour;
                minute = minute == "" ? DateTime.Now.ToString("mm") : minute;

                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(customerId) + "', '" + db.callInsertionText(detailsFilledBy) + "', '" + db.callInsertionText(isCustomerAware) + "', '" + db.callInsertionText(type) + "', '" + db.callInsertionText(isIncome) + "', '" + db.callInsertionText(interest) + "', '" + db.callInsertionText(total) + "', '" + db.callInsertionText(day) + "', '" + db.callInsertionText(month) + "', '" + db.callInsertionText(year) + "', '" + db.callInsertionText(hour) + "', '" + db.callInsertionText(minute) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }

        //database locker_details
        public class LockerDetails
        {
            private string tableName = "locker_details";
            db_connection db = new db_connection();

            private string id = "id";
            private string lockerName = "lockerName";
            private string lockerOwner = "lockerOwner";
            private string description = "lockerDescription";
            private string line1 = "line1";
            private string line2 = "line2";
            private string line3 = "line3";
            private string city = "city";
            private string day = "registeredDay";
            private string month = "registeredMonth";
            private string year = "registeredYear";

            public void newLockerRegistration(string id, string lockerName, string description, string line1, string line2, string line3, string city, string day = "", string month = "", string year = "")
            {
                day = day == "" ? DateTime.Now.ToString("dd") : day;
                month = month == "" ? DateTime.Now.ToString("MM") : month;
                year = year == "" ? DateTime.Now.ToString("yyyy") : year;

                db.createConnection();
                db.command.CommandText = "insert into " + this.tableName + " values ('" + db.callInsertionText(id) + "', '" + db.callInsertionText(lockerName) + "', '" + db.callInsertionText(description) + "', '" + db.callInsertionText(line1) + "', '" + db.callInsertionText(line2) + "', '" + db.callInsertionText(line3) + "', '" + db.callInsertionText(city) + "', '" + db.callInsertionText(day) + "', '" + db.callInsertionText(month) + "', '" + db.callInsertionText(year) + "')";
                db.connection.Open();
                db.command.ExecuteNonQuery();
                db.connection.Close();
            }
        }
    }
}
