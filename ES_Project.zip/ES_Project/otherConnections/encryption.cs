﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ES_Project.otherConnections
{
    class encryption
    {
        public string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);

            using (RijndaelManaged rijndael = new RijndaelManaged())
            {
                rijndael.KeySize = 256;
                rijndael.BlockSize = 128;
                rijndael.Mode = CipherMode.CBC;
                rijndael.Padding = PaddingMode.PKCS7;

                byte[] keyBytes = Encoding.UTF8.GetBytes(new encryption().getSingleHash());
                byte[] ivBytes = new byte[16];

                using (var encryptor = rijndael.CreateEncryptor(keyBytes, ivBytes))
                {
                    byte[] cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                    return Convert.ToBase64String(cipherBytes);
                }
            }
        }

        public string Decrypt(string cipherText)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherText);

            using (RijndaelManaged rijndael = new RijndaelManaged())
            {
                rijndael.KeySize = 256;
                rijndael.BlockSize = 128;
                rijndael.Mode = CipherMode.CBC;
                rijndael.Padding = PaddingMode.PKCS7;

                byte[] keyBytes = Encoding.UTF8.GetBytes(new encryption().getSingleHash());
                byte[] ivBytes = new byte[16];

                using (var decryptor = rijndael.CreateDecryptor(keyBytes, ivBytes))
                {
                    byte[] plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
                    return Encoding.UTF8.GetString(plainBytes);
                }
            }
        }


        private string getSingleHash()
        {
            return "VP4A7rDsFe6EXS3Dz6yY9oEMtP3tUoOj";
        }
    }
}
