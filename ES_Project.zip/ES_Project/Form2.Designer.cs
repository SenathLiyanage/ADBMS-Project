﻿namespace ES_Project
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_NewMor = new System.Windows.Forms.Button();
            this.btn_Pay = new System.Windows.Forms.Button();
            this.btn_Rep = new System.Windows.Forms.Button();
            this.btn_Cus = new System.Windows.Forms.Button();
            this.btn_Web = new System.Windows.Forms.Button();
            this.btn_Mes = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 663);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(17, 610);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(244, 22);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(17, 372);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(243, 54);
            this.button3.TabIndex = 3;
            this.button3.Text = "Log-Out";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(17, 270);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(243, 54);
            this.button2.TabIndex = 2;
            this.button2.Text = "Contact";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(17, 167);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(243, 54);
            this.button1.TabIndex = 1;
            this.button1.Text = "Exchange Details";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(275, 105);
            this.panel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(15, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(249, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "No. 55, New Town, Dehiaththakandiya";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "D. K. Pawning Center";
            // 
            // btn_NewMor
            // 
            this.btn_NewMor.BackgroundImage = global::ES_Project.Properties.Resources.Button_001;
            this.btn_NewMor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_NewMor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_NewMor.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewMor.ForeColor = System.Drawing.Color.Black;
            this.btn_NewMor.Location = new System.Drawing.Point(309, 50);
            this.btn_NewMor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_NewMor.Name = "btn_NewMor";
            this.btn_NewMor.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_NewMor.Size = new System.Drawing.Size(236, 239);
            this.btn_NewMor.TabIndex = 1;
            this.btn_NewMor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_NewMor.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_NewMor.UseVisualStyleBackColor = true;
            this.btn_NewMor.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_Pay
            // 
            this.btn_Pay.BackgroundImage = global::ES_Project.Properties.Resources.Button_002;
            this.btn_Pay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Pay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Pay.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Pay.ForeColor = System.Drawing.Color.Black;
            this.btn_Pay.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Pay.Location = new System.Drawing.Point(597, 50);
            this.btn_Pay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Pay.Name = "btn_Pay";
            this.btn_Pay.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_Pay.Size = new System.Drawing.Size(236, 239);
            this.btn_Pay.TabIndex = 3;
            this.btn_Pay.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Pay.UseVisualStyleBackColor = true;
            this.btn_Pay.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_Rep
            // 
            this.btn_Rep.BackgroundImage = global::ES_Project.Properties.Resources.Button_003;
            this.btn_Rep.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Rep.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Rep.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Rep.ForeColor = System.Drawing.Color.Black;
            this.btn_Rep.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Rep.Location = new System.Drawing.Point(887, 50);
            this.btn_Rep.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Rep.Name = "btn_Rep";
            this.btn_Rep.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_Rep.Size = new System.Drawing.Size(236, 239);
            this.btn_Rep.TabIndex = 4;
            this.btn_Rep.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Rep.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Rep.UseVisualStyleBackColor = true;
            // 
            // btn_Cus
            // 
            this.btn_Cus.BackgroundImage = global::ES_Project.Properties.Resources.Button_05;
            this.btn_Cus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Cus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Cus.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cus.ForeColor = System.Drawing.Color.Black;
            this.btn_Cus.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Cus.Location = new System.Drawing.Point(597, 336);
            this.btn_Cus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Cus.Name = "btn_Cus";
            this.btn_Cus.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_Cus.Size = new System.Drawing.Size(236, 239);
            this.btn_Cus.TabIndex = 6;
            this.btn_Cus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Cus.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Cus.UseVisualStyleBackColor = true;
            // 
            // btn_Web
            // 
            this.btn_Web.BackgroundImage = global::ES_Project.Properties.Resources.Button_06;
            this.btn_Web.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Web.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Web.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Web.ForeColor = System.Drawing.Color.Black;
            this.btn_Web.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Web.Location = new System.Drawing.Point(887, 336);
            this.btn_Web.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Web.Name = "btn_Web";
            this.btn_Web.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_Web.Size = new System.Drawing.Size(236, 239);
            this.btn_Web.TabIndex = 7;
            this.btn_Web.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Web.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Web.UseVisualStyleBackColor = true;
            // 
            // btn_Mes
            // 
            this.btn_Mes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Mes.BackgroundImage")));
            this.btn_Mes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Mes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Mes.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mes.ForeColor = System.Drawing.Color.Black;
            this.btn_Mes.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Mes.Location = new System.Drawing.Point(309, 336);
            this.btn_Mes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Mes.Name = "btn_Mes";
            this.btn_Mes.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.btn_Mes.Size = new System.Drawing.Size(236, 239);
            this.btn_Mes.TabIndex = 5;
            this.btn_Mes.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Mes.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Mes.UseVisualStyleBackColor = true;
            this.btn_Mes.Click += new System.EventHandler(this.button7_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ES_Project.Properties.Resources.images;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1157, 655);
            this.Controls.Add(this.btn_Web);
            this.Controls.Add(this.btn_Cus);
            this.Controls.Add(this.btn_Mes);
            this.Controls.Add(this.btn_Rep);
            this.Controls.Add(this.btn_Pay);
            this.Controls.Add(this.btn_NewMor);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_NewMor;
        private System.Windows.Forms.Button btn_Pay;
        private System.Windows.Forms.Button btn_Rep;
        private System.Windows.Forms.Button btn_Cus;
        private System.Windows.Forms.Button btn_Web;
        private System.Windows.Forms.Button btn_Mes;
    }
}