﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ES_Project.otherConnections;

namespace ES_Project
{
    public partial class frm_registerPawnItem : Form
    {
        private string pawnId;
        public frm_registerPawnItem(string pawnId = "")
        {
            InitializeComponent();
            this.pawnId = pawnId;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new db_connection.PawnedItems().newPawnedItem(textBox3.Text, textBox8.Text, txt_Name.Text, richTextBox1.Text, txt_Con.Text, textBox7.Text, textBox1.Text, textBox2.Text, textBox4.Text, textBox5.Text, Properties.Settings.Default.username, textBox6.Text, textBox9.Text, textBox10.Text, textBox11.Text);
            MessageBox.Show("Registration succesfull.", "EK Pawning center - Item Registration", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void frm_registerPawnItem_Load(object sender, EventArgs e)
        {
            textBox8.Text = this.pawnId;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
