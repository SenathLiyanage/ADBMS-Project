﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ES_Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            txt_Name1.Clear();
            txt_Add1.Clear();
            txt_Nic1.Clear();
            txt_Con1.Clear();
            txt_Amo1.Clear();
            txt_Amo_P.Clear();
            txt_Amo_D.Clear();
            txt_Per1.Clear();
            txt_Weg1.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }
    }
}
