﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ES_Project
{
    internal class ulog
    {
        public static String type;
    }

}
